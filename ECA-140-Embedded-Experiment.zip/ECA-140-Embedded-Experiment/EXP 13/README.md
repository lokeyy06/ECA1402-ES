ADDITION OF ARRAY OF 16 BIT NUMBERS

#include <reg51.h>

void main(void)
{
    unsigned int i;
    unsigned int array[5] =
    {
        0x1111,
        0x2222,
        0x8888,
        0x4444,
        0xABCD
    };

    unsigned long sum = 0;

    for(i=0;i<5;i++)
    {
        sum = sum + array[i];
    }

    P0 = (unsigned char)(sum & 0xFF);
    P1 = (unsigned char)((sum >> 8) & 0xFF);
    P2 = (unsigned char)((sum >> 16) & 0xFF);

    while(1);
}
